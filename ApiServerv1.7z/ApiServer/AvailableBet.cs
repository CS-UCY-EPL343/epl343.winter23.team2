﻿namespace ApiServer
{
    public class AvailableBet
    {
        private int id;
        private int matchId;
        private string name;
        private float odd;
        private string status="open";
        
        //how to deploiment a api server with iis one way: iis deploiment .net 6
        public AvailableBet()
        {

        }
        public AvailableBet(AvailableBet newBet)
        {
            this.id = newBet.id;
            this.matchId = newBet.matchId;
            this.name = newBet.name;
            this.odd = newBet.odd;
        }

        public int Id
        {
            get { return id; }

            set { id = value; }
        }
        public int MatchId
        {
            get { return matchId; }
            set { matchId = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
       public float Odd
        {
            get { return odd; }
            set { odd = value; }
        }
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

    }
}
