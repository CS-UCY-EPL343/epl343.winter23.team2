﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection.Metadata.Ecma335;
using System.Text.RegularExpressions;

namespace ApiServer.Controllers
{


    [Route("api/[controller]/[action]")]
    [ApiController]
    public class HomeController : ControllerBase
    {


        [HttpGet]
        public ActionResult<List<Match>> GetAllMatches()
        {         
          try
            {
                    Helper helper = new Helper();
                    var resultMatches = helper.ReaderMathces("Matches.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                    if (resultMatches.Count() != 0)
                    {
                        return resultMatches;
                    }
                    else
                    {
                        return new List<Match>();
                    }
                
            }

           catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }
        }
        [HttpGet]
        public ActionResult<List<Ticket>> GetAllTickets()
        {
            try
            {
                Helper helper = new Helper();
                var resultTickets = helper.ReaderTickets("Tickets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultTickets.Count() != 0)
                {
                    return resultTickets;
                }
                else
                {
                    return new List<Ticket>();
                }

            }

            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }
        }

        [HttpGet]
        public ActionResult<List<AvailableBet>> GetAllBets()
        {
            try
            {
                Helper helper = new Helper();
                var resultBets = helper.ReaderBets("AvailableBets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultBets != null)
                {
                    return resultBets;
                }
                else
                {
                    return new List<AvailableBet>();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }
        }

        [HttpGet]
        [Route("{id}")]
        public ActionResult<Match> GetSpecificMatch(int id)
        {
            try
            {
                Helper helper = new Helper();
                var resultMatches = helper.ReaderMathces("Matches.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultMatches != null)
                {
                    var finalMatch = resultMatches.Where(match => match.Id == id);
                    if (finalMatch.Count() != 0)
                    {
                        Match match = new Match(finalMatch.Last());
                        return match;
                    }
                    //if there is not a match with this id
                    else
                    {
                        return new Match();
                    }
                }
                //if there is not any match in the list

                else
                {
                    return new Match();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }


        }
        [HttpGet]
        [Route("{id}")]
        public ActionResult<AvailableBet> GetSpecificBet(int id)
        {
            try
            {
                Helper helper = new Helper();
                var resultBets = helper.ReaderBets("AvailableBets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultBets != null)
                {
                    var finalBet = resultBets.Where(bet => bet.Id == id);
                    if (finalBet.Count() != 0)
                    {
                        AvailableBet bet = new AvailableBet(finalBet.Last());
                        return bet;
                    }
                    //if there is not a bet with this id
                    else
                    {
                        return new AvailableBet();
                    }
                }
                //if there is not any bet in the list
                else
                {
                    return new AvailableBet();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }


        }



        [HttpDelete]
        [Route("{id}")]
        public StatusCodeResult DeleteMatch(int id)
        {
            try
            {

                Helper helper = new Helper();
                bool isEqual1 = true;
                //read the json file and convert it to object
                var resultMatches = helper.ReaderMathces("Matches.json");
                var resultBets = helper.ReaderBets("AvailableBets.json");
                // create a clone from the Match object 
                List<Match> resultMatchesClone = new List<Match>();
                if (resultMatches != null)
                {
                    // create a clone from the Bet object
                    resultMatchesClone.AddRange(resultMatches);
                    //remove every json that has the id 
                    resultMatches.RemoveAll(i => i.Id == id);
                    isEqual1 = resultMatchesClone.OrderBy(x => x.Id).SequenceEqual(resultMatches.OrderBy(x => x.Id));

                }
                if (resultBets != null && isEqual1 == false)
                {
                    //remove every json that has the id 
                    resultBets.RemoveAll(i => i.MatchId == id);

                }
                //convert the new object to json
                var newMatchesJson = JsonConvert.SerializeObject(resultMatches);
                var newBetsJson = JsonConvert.SerializeObject(resultBets);
                //write the new json in the file
                helper.WriteToFile("Matches.json", newMatchesJson);
                helper.WriteToFile("AvailableBets.json", newBetsJson);
                return Ok();

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }



        }
        [HttpDelete]
        [Route("{id}")]
        public StatusCodeResult DeleteBet(int id)
        {
            try
            {

                Helper helper = new Helper();
                //read the json file and convert it to object
                var resultBets = helper.ReaderBets("AvailableBets.json");
                List<AvailableBet> betsClone = new List<AvailableBet>();
                Boolean check = true;//true = not deleted bet
                betsClone.AddRange(resultBets);
                if (resultBets != null)
                {
                    //remove every json that has the id 
                    resultBets.RemoveAll(bet => bet.Id == id);
                    if (betsClone.OrderBy(x => x.Id).SequenceEqual(betsClone.OrderBy(x => x.Id)) == false)
                    {
                        check = false;
                    }

                }
                if (check == true)
                {
                    return BadRequest();
                }
                else
                {
                    //convert the new object to json
                    var newBetsJson = JsonConvert.SerializeObject(resultBets);
                    //write the new json in the file
                    helper.WriteToFile("AvailableBets.json", newBetsJson);
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }



        }

        [HttpPost]
        public StatusCodeResult PostMatch(Match match)
        {
            try
            {
                Helper helper = new Helper();
                int existMatch = 0, idMatch;
                Match newMatch = new Match();
                //read the json file and convert it to object
                var resultMatches = helper.ReaderMathces("Matches.json");

                if (resultMatches != null)
                {
                    idMatch = resultMatches.Last().Id + 1;
                    foreach (var item in resultMatches)
                    {
                        if (item.Name.Equals(match.Name) && item.Date.Equals(match.Date) && item.MatchType.Equals(match.MatchType))
                        {
                            existMatch = 1;
                            break;
                        }

                    }
                }
                else
                {
                    resultMatches = new List<Match>();
                    idMatch = 1;
                }

                if (existMatch == 0)
                {
                    newMatch.Id = idMatch;
                    newMatch.MatchType = match.MatchType;
                    newMatch.Name = new string(match.Name);
                    newMatch.Date = new DateTime(match.Date.Year, match.Date.Month, match.Date.Day, match.Date.Hour, match.Date.Minute, 0);
                    resultMatches.Add(newMatch);
                    var newMatchJson = JsonConvert.SerializeObject(resultMatches);
                    helper.WriteToFile("Matches.json", newMatchJson);
                    return Ok();
                }
                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }
        [HttpPost]
        public StatusCodeResult PostBet(AvailableBet bet)
        {
            try
            {
                Helper helper = new Helper();
                int existBet = 0, idMatch;
                AvailableBet newBets = new AvailableBet();
                //read the json file and convert it to object
                var resultBets = helper.ReaderBets("AvailableBets.json");

                if (resultBets != null)
                {

                    idMatch = resultBets.Last().Id + 1;
                    foreach (var item in resultBets)
                    {
                        if (item.Name.Equals(bet.Name) && item.MatchId.Equals(bet.MatchId))
                        {
                            existBet = 1;
                            break;
                        }

                    }
                }
                else
                {
                    resultBets = new List<AvailableBet>();
                    idMatch = 0;
                }

                if (existBet == 0)
                {
                    newBets.Id = idMatch;
                    newBets.MatchId = bet.MatchId;
                    newBets.Name = new string(bet.Name);
                    newBets.Odd = bet.Odd;
                    newBets.Status= "open";
                    resultBets.Add(newBets);
                    var newBetJson = JsonConvert.SerializeObject(resultBets);
                    helper.WriteToFile("AvailableBets.json", newBetJson);
                    return Ok();
                }
                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }

       

        [HttpPost]
        public ReturnBase PostTicket([FromBody]Ticket ticket)
        {
            ReturnBase returnBase = new ReturnBase();

            try
            {
                Boolean check = false;
                Helper helper = new Helper();
                var resultBets = helper.ReaderBets("AvailableBets.json");

                int idTicket;
                Ticket newTicket = new Ticket();
                //read the json file and convert it to object
                var resultTicket = helper.ReaderTickets("Tickets.json");


                List<AvailableBet> ticketBets = new List<AvailableBet>();
                foreach (var item in ticket.Bets)
                {
                    var bet = resultBets.Where(bet => bet.Id == item.Id);

                    if (bet != null)
                    {
                        AvailableBet cloneBet = new AvailableBet(bet.Last());
                        ticketBets.Add(cloneBet);
                    }
                    else
                    {
                        check = true;
                    }

                }
                if (check == false)
                {
                    if (resultTicket != null)
                    {

                        idTicket = resultTicket.Last().Id + 1;

                    }
                    else
                    {
                        resultTicket = new List<Ticket>();
                        idTicket = 1;
                    }

                    newTicket.Id = idTicket;
                    newTicket.Bets = new List<AvailableBet>(ticketBets);
                    newTicket.Amount = ticket.Amount;
                    float total = ticket.Amount;
                    foreach (var item in ticketBets)
                    {
                        total *= item.Odd;
                    }
                    newTicket.Income = total;
                    newTicket.Status = new string(helper.findStatus(ticketBets));

                    resultTicket.Add(newTicket);
                    var newTicketJson = JsonConvert.SerializeObject(resultTicket);
                    helper.WriteToFile("Tickets.json", newTicketJson);
                    returnBase.Id = idTicket;
                    returnBase.Message = "";
                    returnBase.StatusCode = 200;

                }
                else
                {
                    returnBase.Id = 0;
                    returnBase.Message = "There is not any bet that has the id that you have put in the list";
                    returnBase.StatusCode = 400; //bad request

                }
                return returnBase;

            }
            catch (Exception ex)
            {
                // return StatusCode(StatusCodes.Status500InternalServerError); 
                returnBase.Id = 0;
                returnBase.Message = "error with the server(json), maybe something wrong with the structure of the json";
                returnBase.StatusCode = 500; //bad request
                return returnBase;
            }

        }
       
        [HttpPut]

        public StatusCodeResult CancelTicket(int id)
        {
            try
            {
                Helper helper = new Helper();
                var resultTickets = helper.ReaderTickets("Tickets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultTickets != null)
                {
                    var finalTicket = resultTickets.Where(ticket => ticket.Id == id);
                    if (finalTicket.Count() != 0)
                    {
                        Ticket ticket = new Ticket(finalTicket.Last());
                        ticket.Status = "cancell";
                        resultTickets.RemoveAll(i => i.Id == id);
                        resultTickets.Add(ticket);
                        var newTicketJson = JsonConvert.SerializeObject(resultTickets);
                        helper.WriteToFile("Tickets.json", newTicketJson);
                        return Ok();

                    }
                    else
                    {
                        return BadRequest();
                    }


                }
                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }
        [HttpPut]
        public StatusCodeResult finishBet(AvailableBet betFinish)
        {
            try
            {
                int check = 0;
                Helper helper = new Helper();
                List<Ticket> tickets = new List<Ticket>();
                var resultBets = helper.ReaderBets("AvailableBets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultBets != null)
                {
                    var finalBet = resultBets.Where(bet => bet.Id == betFinish.Id);
                    if (finalBet.Count() != 0)
                    {
                        AvailableBet bet = new AvailableBet(finalBet.Last());
                        bet.Status = betFinish.Status;
                        resultBets.RemoveAll(i => i.Id == betFinish.Id);
                        resultBets.Add(bet);
                        var newBetJson = JsonConvert.SerializeObject(resultBets);
                        helper.WriteToFile("AvailableBets.json", newBetJson);
                        var resultTickets = helper.ReaderTickets("Tickets.json");
                        List<Ticket> resultTicketsClone = new List<Ticket>(resultTickets);
                        
                        if (resultTickets != null)
                        {
                            foreach (var ticket in resultTicketsClone)
                            {
                                Ticket ticketClone = new Ticket(ticket);
                                foreach (var eachBet in ticketClone.Bets)
                                {
                                    if (eachBet.Id == bet.Id)
                                    {
                                        ticket.Bets.RemoveAll(i => i.Id == betFinish.Id);
                                        ticket.Bets.Add(betFinish);
                                        tickets.Add(ticket);
                                        resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                        resultTickets.Add(ticket);
                                       
                                        break;
                                    }

                                }

                            }
                            var newTicketJson = JsonConvert.SerializeObject(resultTickets);
                            helper.WriteToFile("Tickets.json", newTicketJson);


                            if (bet.Status.Equals("lost"))
                            {
                               foreach(var ticket in tickets)
                                {
                                    ticket.Status = "lost";
                                    resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                    resultTickets.Add(ticket);
                                    var newTickenJson = JsonConvert.SerializeObject(resultTickets);
                                    helper.WriteToFile("Tickets.json", newTickenJson);

                                }
                            }
                            else
                            {
                                foreach (var ticket in tickets)
                                {
                                    if (ticket.Status.Equals("lost") == false) {
                                        foreach (var betOfTicket in ticket.Bets)
                                        {
                                            if (betOfTicket.Status.Equals("open") && betOfTicket.Id != bet.Id)
                                            {
                                                ticket.Status = "open";
                                                check = 1;
                                                break;
                                            }
                                            if (check==0)
                                            {   
                                                ticket.Status = "won";

                                            }
                                        }
                                        resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                        resultTickets.Add(ticket);
                                        var newTickenJson = JsonConvert.SerializeObject(resultTickets);
                                        helper.WriteToFile("Tickets.json", newTickenJson);
                                    }
                                    else
                                    {
                                        foreach (var betOfTicket in ticket.Bets)
                                        {
                                            if (betOfTicket.Status.Equals("lost") )
                                            {

                                                ticket.Status = "lost";
                                                check = 2;
                                                break;
                                            }
                                            else if (betOfTicket.Status.Equals("open") && betOfTicket.Id != bet.Id)
                                            {
                                                ticket.Status = "open";
                                                check = 1;
                                                
                                            }
                                            if (check == 0)
                                            {
                                                ticket.Status = "won";

                                            }
                                        }
                                        resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                        resultTickets.Add(ticket);
                                        var newTickenJson = JsonConvert.SerializeObject(resultTickets);
                                        helper.WriteToFile("Tickets.json", newTickenJson);

                                    }
                              
                                }
                            }




                        }
                        return Ok();


                    }
                    else
                    {
                        return BadRequest();
                    }



                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }




    }


}

//backoroud proccess  gia na kamnei update to status tou kathe game sto ticket 

