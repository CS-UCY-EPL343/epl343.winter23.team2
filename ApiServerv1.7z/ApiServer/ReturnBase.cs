﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace ApiServer
{
    public class ReturnBase
    {
        private int id;
        private string message;
        private int statusCode; //1 200 ,2 404, 3 500

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Message
        {
            get { return message; }
            set { message = value; }
        }
        public int StatusCode
        {
            get { return statusCode; }
            set { statusCode = value; }
        }
    }
}