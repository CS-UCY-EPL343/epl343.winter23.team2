﻿using Newtonsoft.Json;

namespace ApiServer
{
    public class Helper
    {
      
        public  List<Match> ReaderMathces(string filePath)
        {
                StreamReader reader = new(filePath);
                var json = reader.ReadToEnd();
                var jsonToObj = JsonConvert.DeserializeObject<List<Match>>(json); //convert the json to object
                reader.Close();
            return jsonToObj;
        }
        public List<AvailableBet> ReaderBets(string filePath)
        {
            StreamReader reader = new(filePath);
            var json = reader.ReadToEnd();
            var jsonToObj = JsonConvert.DeserializeObject<List<AvailableBet>>(json); //convert the json to object
            reader.Close();
            return jsonToObj;

        }
        public List<Ticket> ReaderTickets(string filePath)
        {
            StreamReader reader = new(filePath);
            var json = reader.ReadToEnd();
            var jsonToObj = JsonConvert.DeserializeObject<List<Ticket>>(json); //convert the json to object
            reader.Close();
            return jsonToObj;

        }
        public void  WriteToFile(string filePath, string text)
        {
            try
            {
                System.IO.File.WriteAllText(filePath, text);
            }
            catch {
                Console.WriteLine("Can not write in the json file");
            }
        }

        public string findStatus(List<AvailableBet> bets)
        {
            string status=null;
            DateTime maxDate=new DateTime();
            Helper helper = new Helper();
            Match match=new Match();
            Match matchMaxDate=new Match();
            var resultMatches = helper.ReaderMathces("Matches.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
      //finds the max date that a bet will be expired
            foreach (var item in bets)
            {

                if (resultMatches != null)
                {
                    var finalMatch = resultMatches.Where(match => match.Id == item.MatchId);
                    
                    if (finalMatch.Count() != 0 )
                    {
                        match = new Match(finalMatch.Last());

                    }
                ///    if(DateTime.Compare(match.Date,DateTime.Now) < 0) {
                 ///       status = "error"; //there is match that its date are expired, can not be in any ticket
                 ///   }
                    var result=DateTime.Compare(maxDate, match.Date);
                    if(result< 0)// the second object will be later than the first
                    {
                        maxDate = new DateTime(match.Date.Year,match.Date.Month,match.Date.Day,match.Date.Hour,match.Date.Minute,match.Date.Second);
                        matchMaxDate = new Match(match);
                    }


                }
              
                }
            if (matchMaxDate.FinishMatch==false)
            {
                status = "open";
            }
            else
            {
                status= "close";
            }
            Console.WriteLine(status);
            return status;

        }
        
        

        }
}
