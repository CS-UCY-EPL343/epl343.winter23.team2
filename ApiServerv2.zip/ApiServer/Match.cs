﻿namespace ApiServer
{
    public class Match
    {

        public enum Mtype
        {
            Football = 1,
            Basketball = 2,
            Tennis = 3,
        }//enum


        private int id;
        private string name;
        private Mtype matchType;
        private DateTime date;
        private bool finishMatch;

        public Match()
        {

        }
        public Match(Match newMatch)
        {
            this.id = newMatch.id;
            this.name = newMatch.name;
            this.matchType = newMatch.matchType;
            this.date = new DateTime(newMatch.date.Year, newMatch.date.Month, newMatch.date.Day, newMatch.date.Hour, newMatch.date.Minute,0);
        }
        public int Id

        {
            get { return id; }

            set { id = value; }
        }
        public String Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public Mtype MatchType
        {
            get { return matchType; }
            set { matchType = value; }
        }
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
       
       public bool FinishMatch
        {
            get { return finishMatch; }
            set { finishMatch = value; }
        }
    }
}
