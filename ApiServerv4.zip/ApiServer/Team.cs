﻿using System.Globalization;

namespace ApiServer
{
    public class Team
    {
        private String name;


        public String Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
    }
}