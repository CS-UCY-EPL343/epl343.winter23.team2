﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection.Metadata.Ecma335;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;



namespace ApiServer.Controllers
{
    

    [Route("api/[controller]/[action]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        String useremail;//"john@example.com";
        public readonly IConfiguration _configuration;
        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpPost]
        public ActionResult PostTicket(Ticket ticket)
        {
            // try
            //{
            String fileContent = "";
            using (FileStream fileStream = new FileStream("userName.txt", FileMode.Open))
            {
                // Create a StreamReader to read the contents of the file
                using (StreamReader reader = new StreamReader(fileStream))
                {
                    // Read the entire content of the file
                    fileContent = reader.ReadToEnd();

                    // Do something with the file content (e.g., print it)
                    Console.WriteLine("File Content: " + fileContent);
                }
            }
            using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString()))
                {
                    con.Open(); // Open the connection

                    string query = "INSERT INTO bet_tickets (the_date,stake,total_odds,the_user)";
                    query += " VALUES (@date, @stake, @total_odds,@user)";

                    using (SqlCommand myCommand = new SqlCommand(query, con))
                    {
                    myCommand.Parameters.AddWithValue("@date", ticket.Date);
                    //myCommand.Parameters.AddWithValue("@ticketnum", ticket.Id);
                    myCommand.Parameters.AddWithValue("@stake", ticket.Amount);
                    myCommand.Parameters.AddWithValue("@total_odds", ticket.Income);
                    myCommand.Parameters.AddWithValue("@user", fileContent);


                    myCommand.ExecuteNonQuery();
                    }
                SqlConnection con2 = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString());
                SqlDataAdapter da2 = new SqlDataAdapter("select top(1) * from bet_tickets order by ticket_number desc", con2);
                DataTable dt = new DataTable();
                da2.Fill(dt);
                Helper helper = new Helper();
                Ticket newTisket = new Ticket();
                newTisket.Id = Convert.ToInt32(dt.Rows[0]["ticket_number"]);
                string query2 = "INSERT INTO bets (odds,win_loss_pending,specification,match_played,bet_ticket)";
                    query2 += " VALUES (@odds, @win_loss_pending, @specification,@match_played,@bet_ticket)";
                    int i;
                    for (i = 0; i < ticket.Bets.Count(); i++)
                    {
                        using (SqlCommand myCommand1 = new SqlCommand(query2, con))
                        {
                            myCommand1.Parameters.AddWithValue("@odds", ticket.Bets[i].Odd);
                            //myCommand1.Parameters.AddWithValue("@betid", ticket.Bets[i].Id);
                            myCommand1.Parameters.AddWithValue("@win_loss_pending", ticket.Bets[i].Status);
                        myCommand1.Parameters.AddWithValue("@match_played", ticket.Bets[i].MatchId);
                        myCommand1.Parameters.AddWithValue("@specification", ticket.Bets[i].Name);
                            myCommand1.Parameters.AddWithValue("@bet_ticket", newTisket.Id);

                        myCommand1.ExecuteNonQuery();
                        }
                    }
                    return Ok();
                }
            //}
            //catch (Exception ex)
            //{
              //  return StatusCode(StatusCodes.Status500InternalServerError);
            //}


        }




        [HttpDelete]
        public ActionResult Deleteticket(int ticketid)
        {

          //  try
            //{
                using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString()))
                {
                    con.Open();

                    // Assuming you have a table named "YourTable" with a primary key column named "Id"
                    string deleteQuery = "delete from bets where bet_ticket = @ticket_id";
                    string deleteQuery2= "delete from bet_tickets where ticket_number = @ticket_id2";
                    using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, con))
                    {
                        // Replace "@Id" with the actual parameter name and value
                        deleteCommand.Parameters.AddWithValue("@ticket_id", ticketid);

                        // Execute the delete command
                        deleteCommand.ExecuteNonQuery();
                    }
                    using (SqlCommand deleteCommand2 = new SqlCommand(deleteQuery2, con))
                    {
                        // Replace "@Id" with the actual parameter name and value
                        deleteCommand2.Parameters.AddWithValue("@ticket_id2", ticketid);

                        // Execute the delete command
                        deleteCommand2.ExecuteNonQuery();
                    }
                }

                return Ok();
           // }
            //catch (Exception ex)
            //{
                // Handle exceptions appropriately
              //  return StatusCode(StatusCodes.Status500InternalServerError);
            //}

        }

        [HttpPut]
        public ActionResult user_signup([FromBody] User user)
        {
            String fileContent = "";
            using (FileStream fileStream = new FileStream("userName.txt", FileMode.Truncate))
            {
                // The file is truncated, but we need to recreate it
                fileStream.Close();

                using (FileStream newFileStream = new FileStream("userName.txt", FileMode.Create))
                {
                    // Create a StreamWriter to write the new string to the file
                    using (StreamWriter writer = new StreamWriter(newFileStream))
                    {
                        writer.Write(user.Email);
                    }
                }
            }
                using (FileStream fileStream = new FileStream("userName.txt", FileMode.Open))
                {
                    // Create a StreamReader to read the contents of the file
                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        // Read the entire content of the file
                        fileContent = reader.ReadToEnd();

                        // Do something with the file content (e.g., print it)
                        Console.WriteLine("File Content: " + fileContent);
                    }
                }
            
            try
            {
                using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString()))
                {
                    con.Open(); // Open the connection

                    string query = "INSERT INTO users (name, surname, password, phone, Email)";
                    query += " VALUES (@name, @surname, @password, @phone, @Email)";

                    using (SqlCommand myCommand = new SqlCommand(query, con))
                    {
                        myCommand.Parameters.AddWithValue("@name", user.Name);
                        myCommand.Parameters.AddWithValue("@surname", user.Surname);
                        myCommand.Parameters.AddWithValue("@password", user.Password);
                        myCommand.Parameters.AddWithValue("@phone", user.Phone);
                        myCommand.Parameters.AddWithValue("@Email", user.Email);

                        myCommand.ExecuteNonQuery();
                    }

                    return Ok();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }
        [HttpPut]
        public ActionResult<int> user_verify([FromBody] User user)
        {
            String fileContent = "";
            using (FileStream fileStream = new FileStream("userName.txt", FileMode.Truncate))
            {
                // The file is truncated, but we need to recreate it
                fileStream.Close();

                using (FileStream newFileStream = new FileStream("userName.txt", FileMode.Create))
                {
                    // Create a StreamWriter to write the new string to the file
                    using (StreamWriter writer = new StreamWriter(newFileStream))
                    {
                        writer.Write(user.Email);
                    }
                }
            }
            using (FileStream fileStream = new FileStream("userName.txt", FileMode.Open))
            {
                // Create a StreamReader to read the contents of the file
                using (StreamReader reader = new StreamReader(fileStream))
                {
                    // Read the entire content of the file
                    fileContent = reader.ReadToEnd();

                    // Do something with the file content (e.g., print it)
                    Console.WriteLine("File Content: " + fileContent);
                }
            }

            try
            {
                Helper H = new Helper();

                useremail = new string(user.Email);
                Console.WriteLine(useremail);
                SqlConnection con = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString());
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM users WHERE @fileContent=users.Email AND @pass=users.password ", con);
                da.SelectCommand.Parameters.AddWithValue("@fileContent", user.Email);
                da.SelectCommand.Parameters.AddWithValue("@pass", user.Password);


                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    return 0;// there is not in the server the user
                }
                else
                {
                    return 1;//there is in the server
                }
            }


            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }
        }
        [HttpGet]
        public ActionResult<List<Match>> GetAllMatches()
        { 

            try
            {
               
                SqlConnection con = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString());
                SqlDataAdapter da = new SqlDataAdapter("select * from matches",con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                Helper helper = new Helper();
                if (dt.Rows.Count>0)
                {
                    for(int i = 0; i < dt.Rows.Count; i++) 
                    {
                        int  idMatch;
                        Match newMatch = new Match();
                        //read the json file and convert it to object
                        var resultMatchess = helper.ReaderMathces("Matches.json");
                        if (resultMatchess == null)
                        { 
                            resultMatchess = new List<Match>();
                        }

                       
                            newMatch.Id = Convert.ToInt32(dt.Rows[i]["id"]);
                            newMatch.MatchType = Match.Mtype.Football;
                            newMatch.Team1 = new Team();
                            newMatch.Team2 = new Team();
                            newMatch.Team1.Name = Convert.ToString(dt.Rows[i]["Team1"]);
                            newMatch.Team2.Name = Convert.ToString(dt.Rows[i]["Team2"]);
                            newMatch.Name = newMatch.Team1.Name + " - " + newMatch.Team2.Name;
                            newMatch.Date = Convert.ToDateTime(dt.Rows[i]["date_of_the_match"]);
                            resultMatchess.Add(newMatch);
                            var newMatchJson = JsonConvert.SerializeObject(resultMatchess);
                            helper.WriteToFile("Matches.json", newMatchJson);
                        
                    }
                }



                    //Helper helper = new Helper();
                    var resultMatches = helper.ReaderMathces("Matches.json"); // reads the json with the matches and returns a list with the matches tha exists in the json

                helper.DeleteMatchesjson();
                if (resultMatches.Count() != 0)
                    {
                        return resultMatches;
                    }
                    else
                    {
                        return new List<Match>();
                    }
                
            }

           catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }
        }
        [HttpGet]
        public ActionResult<List<Ticket>> GetAllTickets()
        {
           

            try
            {
                String fileContent = "";
                using (FileStream fileStream = new FileStream("userName.txt", FileMode.Open))
                {
                    // Create a StreamReader to read the contents of the file
                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        // Read the entire content of the file
                        fileContent = reader.ReadToEnd();

                        // Do something with the file content (e.g., print it)
                        Console.WriteLine("File Content: " + fileContent);
                    }
                }
                SqlConnection con = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString());
                SqlDataAdapter da2 = new SqlDataAdapter("select * from bet_tickets where the_user LIKE @user", con);
                da2.SelectCommand.Parameters.AddWithValue("@user", fileContent);
                DataTable dt = new DataTable();
                da2.Fill(dt);
                Helper helper = new Helper();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int idbetticket;
                        Ticket newTisket = new Ticket();
                        //read the json file and convert it to object
                        var resultTickets = helper.ReaderTickets("Tickets.json");
                        if (resultTickets.Count == 0)
                        {
                            resultTickets = new List<Ticket>();
                        }


                        newTisket.Id = Convert.ToInt32(dt.Rows[i]["ticket_number"]);
                        newTisket.Date= Convert.ToDateTime(dt.Rows[i]["the_date"]);
                        newTisket.Status = "open";
                        //newTisket.Bets = new List<AvailableBet>();

                        SqlDataAdapter da1 = new SqlDataAdapter("select * from bets where bet_ticket = @search", con);
                        da1.SelectCommand.Parameters.AddWithValue("@search", newTisket.Id);
                        DataTable dt1 = new DataTable();
                        da1.Fill(dt1);
                        Helper helper1 = new Helper();
                        helper1.DeleteBetsjson();
                       
                        
                        if (dt1.Rows.Count > 0)
                        {
                            for (int j = 0; j < dt1.Rows.Count; j++)
                            {
                               
                                AvailableBet newbet = new AvailableBet();
                                //read the json file and convert it to object
                                var resultBets = helper1.ReaderBets("AvailableBets.json");
                                if (resultBets.Count == 0)
                                {
                                    resultBets = new List<AvailableBet>();
                                }

                                newbet.Id = Convert.ToInt32(dt1.Rows[j]["betid"]);
                                newbet.MatchId = Convert.ToInt32(dt1.Rows[j]["match_played"]);
                                newbet.Name = (dt1.Rows[j]["specification"]).ToString();
                                newbet.Odd = (float)Convert.ToDecimal(dt1.Rows[j]["odds"]);
                                newbet.Status = (dt1.Rows[j]["win_loss_pending"]).ToString();
                                
                                resultBets.Add(newbet);
                                
                                var newBetJson = JsonConvert.SerializeObject(resultBets);
                                helper.WriteToFile("AvailableBets.json", newBetJson);

                            }
                        }
                        var resultBetss = helper.ReaderBets("AvailableBets.json");
                        helper1.DeleteBetsjson();
                   
                        newTisket.Bets= resultBetss;
                        newTisket.Amount = (float)Convert.ToDouble(dt.Rows[i]["Stake"]);
                        newTisket.Income = (float)Convert.ToDouble(dt.Rows[i]["total_odds"]) ;
                        resultTickets.Add(newTisket);
                        var newTicketJson = JsonConvert.SerializeObject(resultTickets);
                        helper.WriteToFile("Tickets.json", newTicketJson);

                    }
                }
                var resultTicketss = helper.ReaderTickets("Tickets.json");
                helper.DeleteTicketsjson();
                if (resultTicketss.Count() != 0)
                {
                    return resultTicketss;
                }
                else
                {
                    return new List<Ticket>();
                }

            }

            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }
        }

        [HttpGet]
        public ActionResult<List<AvailableBet>> GetAllBets()
        {
            try
            {
                /*Helper helper = new Helper();
                var resultBets = helper.ReaderBets("AvailableBets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultBets != null)
                {
                    return resultBets;
                }
                else
                {
                    return new List<AvailableBet>();
                }*/

                SqlConnection con = new SqlConnection(_configuration.GetConnectionString("HomeApp").ToString());
                SqlDataAdapter da = new SqlDataAdapter("select * from available_bets", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                Helper helper = new Helper();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        
                        AvailableBet newAvailableBet = new AvailableBet();
                        //read the json file and convert it to object
                        var resultAvailableBets = helper.ReaderBets("AvailableBets.json");
                        if (resultAvailableBets.Count==0)
                        {
                            resultAvailableBets = new List<AvailableBet>();
                        }


                        newAvailableBet.Id = Convert.ToInt32(dt.Rows[i]["abetid"]);
                        newAvailableBet.MatchId = Convert.ToInt32(dt.Rows[i]["matchid"]);
                        newAvailableBet.Odd = (float)Convert.ToDouble(dt.Rows[i]["odds"]);
                        newAvailableBet.Name = (dt.Rows[i]["Specif"]).ToString();
                        newAvailableBet.Status = (dt.Rows[i]["win_loss_pending"]).ToString();
                        resultAvailableBets.Add(newAvailableBet);
                        var newMatchJson = JsonConvert.SerializeObject(resultAvailableBets);
                        helper.WriteToFile("AvailableBets.json", newMatchJson);

                    }
                }



                //Helper helper = new Helper();
                var resultAvailableBetss = helper.ReaderBets("AvailableBets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json

                helper.DeleteBetsjson();
                if (resultAvailableBetss.Count() != 0)
                {
                    return resultAvailableBetss;
                }
                else
                {
                    return new List<AvailableBet>();
                }

            
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }
        }

        [HttpGet]
        [Route("{id}")]
        public ActionResult<Match> GetSpecificMatch(int id)
        {
            try
            {
                Helper helper = new Helper();
                var resultMatches = helper.ReaderMathces("Matches.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultMatches != null)
                {
                    var finalMatch = resultMatches.Where(match => match.Id == id);
                    if (finalMatch.Count() != 0)
                    {
                        Match match = new Match(finalMatch.Last());
                        return match;
                    }
                    //if there is not a match with this id
                    else
                    {
                        return new Match();
                    }
                }
                //if there is not any match in the list

                else
                {
                    return new Match();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }


        }
        [HttpGet]
        [Route("{id}")]
        public ActionResult<AvailableBet> GetSpecificBet(int id)
        {
            try
            {
                Helper helper = new Helper();
                var resultBets = helper.ReaderBets("AvailableBets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultBets != null)
                {
                    var finalBet = resultBets.Where(bet => bet.Id == id);
                    if (finalBet.Count() != 0)
                    {
                        AvailableBet bet = new AvailableBet(finalBet.Last());
                        return bet;
                    }
                    //if there is not a bet with this id
                    else
                    {
                        return new AvailableBet();
                    }
                }
                //if there is not any bet in the list
                else
                {
                    return new AvailableBet();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }


        }
       
        [HttpDelete]
        [Route("{id}")]
        public StatusCodeResult DeleteMatch(int id)
        {
            try
            {

                Helper helper = new Helper();
                bool isEqual1 = true;
                //read the json file and convert it to object
                var resultMatches = helper.ReaderMathces("Matches.json");
                var resultBets = helper.ReaderBets("AvailableBets.json");
                // create a clone from the Match object 
                List<Match> resultMatchesClone = new List<Match>();
                if (resultMatches != null)
                {
                    // create a clone from the Bet object
                    resultMatchesClone.AddRange(resultMatches);
                    //remove every json that has the id 
                    resultMatches.RemoveAll(i => i.Id == id);
                    isEqual1 = resultMatchesClone.OrderBy(x => x.Id).SequenceEqual(resultMatches.OrderBy(x => x.Id));

                }
                if (resultBets != null && isEqual1 == false)
                {
                    //remove every json that has the id 
                    resultBets.RemoveAll(i => i.MatchId == id);

                }
                //convert the new object to json
                var newMatchesJson = JsonConvert.SerializeObject(resultMatches);
                var newBetsJson = JsonConvert.SerializeObject(resultBets);
                //write the new json in the file
                helper.WriteToFile("Matches.json", newMatchesJson);
                helper.WriteToFile("AvailableBets.json", newBetsJson);
                return Ok();

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }



        }
        [HttpDelete]
        [Route("{id}")]
        public StatusCodeResult DeleteBet(int id)
        {
            try
            {

                Helper helper = new Helper();
                //read the json file and convert it to object
                var resultBets = helper.ReaderBets("AvailableBets.json");
                List<AvailableBet> betsClone = new List<AvailableBet>();
                Boolean check = true;//true = not deleted bet
                betsClone.AddRange(resultBets);
                if (resultBets != null)
                {
                    //remove every json that has the id 
                    resultBets.RemoveAll(bet => bet.Id == id);
                    if (betsClone.OrderBy(x => x.Id).SequenceEqual(betsClone.OrderBy(x => x.Id)) == false)
                    {
                        check = false;
                    }

                }
                if (check == true)
                {
                    return BadRequest();
                }
                else
                {
                    //convert the new object to json
                    var newBetsJson = JsonConvert.SerializeObject(resultBets);
                    //write the new json in the file
                    helper.WriteToFile("AvailableBets.json", newBetsJson);
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }



        }

        [HttpPost]
        public StatusCodeResult PostMatch(Match match)
        {
            try
            {
                Helper helper = new Helper();
                int existMatch = 0, idMatch;
                Match newMatch = new Match();
                //read the json file and convert it to object
                var resultMatches = helper.ReaderMathces("Matches.json");

                if (resultMatches != null)
                {
                    idMatch = resultMatches.Last().Id + 1;
                    foreach (var item in resultMatches)
                    {
                        if (item.Name.Equals(match.Name) && item.Date.Equals(match.Date) && item.MatchType.Equals(match.MatchType))
                        {
                            existMatch = 1;
                            break;
                        }

                    }
                }
                else
                {
                    resultMatches = new List<Match>();
                    idMatch = 1;
                }

                if (existMatch == 0)
                {
                    newMatch.Id = idMatch;
                    newMatch.MatchType = match.MatchType;
                    newMatch.Name = new string(match.Name);
                    newMatch.Date = new DateTime(match.Date.Year, match.Date.Month, match.Date.Day, match.Date.Hour, match.Date.Minute, 0);
                    resultMatches.Add(newMatch);
                    var newMatchJson = JsonConvert.SerializeObject(resultMatches);
                    helper.WriteToFile("Matches.json", newMatchJson);
                    return Ok();
                }
                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }
        [HttpPost]
        public StatusCodeResult PostBet(AvailableBet bet)
        {
            try
            {
                Helper helper = new Helper();
                int existBet = 0, idMatch;
                AvailableBet newBets = new AvailableBet();
                //read the json file and convert it to object
                var resultBets = helper.ReaderBets("AvailableBets.json");

                if (resultBets != null)
                {

                    idMatch = resultBets.Last().Id + 1;
                    foreach (var item in resultBets)
                    {
                        if (item.Name.Equals(bet.Name) && item.MatchId.Equals(bet.MatchId))
                        {
                            existBet = 1;
                            break;
                        }

                    }
                }
                else
                {
                    resultBets = new List<AvailableBet>();
                    idMatch = 0;
                }

                if (existBet == 0)
                {
                    newBets.Id = idMatch;
                    newBets.MatchId = bet.MatchId;
                    newBets.Name = new string(bet.Name);
                    newBets.Odd = bet.Odd;
                    newBets.Status= "open";
                    resultBets.Add(newBets);
                    var newBetJson = JsonConvert.SerializeObject(resultBets);
                    helper.WriteToFile("AvailableBets.json", newBetJson);
                    return Ok();
                }
                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }

       

       /* [HttpPost]
        public ReturnBase PostTicket([FromBody]Ticket ticket)
        {
            ReturnBase returnBase = new ReturnBase();

            try
            {
                Boolean check = false;
                Helper helper = new Helper();
                var resultBets = helper.ReaderBets("AvailableBets.json");

                int idTicket;
                Ticket newTicket = new Ticket();
                //read the json file and convert it to object
                var resultTicket = helper.ReaderTickets("Tickets.json");


                List<AvailableBet> ticketBets = new List<AvailableBet>();
                foreach (var item in ticket.Bets)
                {
                    var bet = resultBets.Where(bet => bet.Id == item.Id);

                    if (bet != null)
                    {
                        AvailableBet cloneBet = new AvailableBet(bet.Last());
                        ticketBets.Add(cloneBet);
                    }
                    else
                    {
                        check = true;
                    }

                }
                if (check == false)
                {
                    if (resultTicket != null)
                    {

                        idTicket = resultTicket.Last().Id + 1;

                    }
                    else
                    {
                        resultTicket = new List<Ticket>();
                        idTicket = 1;
                    }

                    newTicket.Id = idTicket;
                    newTicket.Bets = new List<AvailableBet>(ticketBets);
                    newTicket.Amount = ticket.Amount;
                    float total = ticket.Amount;
                    foreach (var item in ticketBets)
                    {
                        total *= item.Odd;
                    }
                    newTicket.Income = total;
                    newTicket.Status = new string(helper.findStatus(ticketBets));

                    resultTicket.Add(newTicket);
                    var newTicketJson = JsonConvert.SerializeObject(resultTicket);
                    helper.WriteToFile("Tickets.json", newTicketJson);
                    returnBase.Id = idTicket;
                    returnBase.Message = "";
                    returnBase.StatusCode = 200;

                }
                else
                {
                    returnBase.Id = 0;
                    returnBase.Message = "There is not any bet that has the id that you have put in the list";
                    returnBase.StatusCode = 400; //bad request

                }
                return returnBase;

            }
            catch (Exception ex)
            {
                // return StatusCode(StatusCodes.Status500InternalServerError); 
                returnBase.Id = 0;
                returnBase.Message = "error with the server(json), maybe something wrong with the structure of the json";
                returnBase.StatusCode = 500; //bad request
                return returnBase;
            }

        }

       */
        [HttpPut]

        public StatusCodeResult CancelTicket(int id)
        {
            try
            {
                Helper helper = new Helper();
                var resultTickets = helper.ReaderTickets("Tickets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultTickets != null)
                {
                    var finalTicket = resultTickets.Where(ticket => ticket.Id == id);
                    if (finalTicket.Count() != 0)
                    {
                        Ticket ticket = new Ticket(finalTicket.Last());
                        ticket.Status = "cancell";
                        resultTickets.RemoveAll(i => i.Id == id);
                        resultTickets.Add(ticket);
                        var newTicketJson = JsonConvert.SerializeObject(resultTickets);
                        helper.WriteToFile("Tickets.json", newTicketJson);
                        return Ok();

                    }
                    else
                    {
                        return BadRequest();
                    }


                }
                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }
        [HttpPut]
        public StatusCodeResult finishBet(AvailableBet betFinish)
        {
            try
            {
                int check = 0;
                Helper helper = new Helper();
                List<Ticket> tickets = new List<Ticket>();
                var resultBets = helper.ReaderBets("AvailableBets.json"); // reads the json with the matches and returns a list with the matches tha exists in the json
                if (resultBets != null)
                {
                    var finalBet = resultBets.Where(bet => bet.Id == betFinish.Id);
                    if (finalBet.Count() != 0)
                    {
                        AvailableBet bet = new AvailableBet(finalBet.Last());
                        bet.Status = betFinish.Status;
                        resultBets.RemoveAll(i => i.Id == betFinish.Id);
                        resultBets.Add(bet);
                        var newBetJson = JsonConvert.SerializeObject(resultBets);
                        helper.WriteToFile("AvailableBets.json", newBetJson);
                        var resultTickets = helper.ReaderTickets("Tickets.json");
                        List<Ticket> resultTicketsClone = new List<Ticket>(resultTickets);
                        
                        if (resultTickets != null)
                        {
                            foreach (var ticket in resultTicketsClone)
                            {
                                Ticket ticketClone = new Ticket(ticket);
                                foreach (var eachBet in ticketClone.Bets)
                                {
                                    if (eachBet.Id == bet.Id)
                                    {
                                        ticket.Bets.RemoveAll(i => i.Id == betFinish.Id);
                                        ticket.Bets.Add(betFinish);
                                        tickets.Add(ticket);
                                        resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                        resultTickets.Add(ticket);
                                       
                                        break;
                                    }

                                }

                            }
                            var newTicketJson = JsonConvert.SerializeObject(resultTickets);
                            helper.WriteToFile("Tickets.json", newTicketJson);


                            if (bet.Status.Equals("lost"))
                            {
                               foreach(var ticket in tickets)
                                {
                                    ticket.Status = "lost";
                                    resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                    resultTickets.Add(ticket);
                                    var newTickenJson = JsonConvert.SerializeObject(resultTickets);
                                    helper.WriteToFile("Tickets.json", newTickenJson);

                                }
                            }
                            else
                            {
                                foreach (var ticket in tickets)
                                {
                                    if (ticket.Status.Equals("lost") == false) {
                                        foreach (var betOfTicket in ticket.Bets)
                                        {
                                            if (betOfTicket.Status.Equals("open") && betOfTicket.Id != bet.Id)
                                            {
                                                ticket.Status = "open";
                                                check = 1;
                                                break;
                                            }
                                            if (check==0)
                                            {   
                                                ticket.Status = "won";

                                            }
                                        }
                                        resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                        resultTickets.Add(ticket);
                                        var newTickenJson = JsonConvert.SerializeObject(resultTickets);
                                        helper.WriteToFile("Tickets.json", newTickenJson);
                                    }
                                    else
                                    {
                                        foreach (var betOfTicket in ticket.Bets)
                                        {
                                            if (betOfTicket.Status.Equals("lost") )
                                            {

                                                ticket.Status = "lost";
                                                check = 2;
                                                break;
                                            }
                                            else if (betOfTicket.Status.Equals("open") && betOfTicket.Id != bet.Id)
                                            {
                                                ticket.Status = "open";
                                                check = 1;
                                                
                                            }
                                            if (check == 0)
                                            {
                                                ticket.Status = "won";

                                            }
                                        }
                                        resultTickets.RemoveAll(i => i.Id == ticket.Id);
                                        resultTickets.Add(ticket);
                                        var newTickenJson = JsonConvert.SerializeObject(resultTickets);
                                        helper.WriteToFile("Tickets.json", newTickenJson);

                                    }
                              
                                }
                            }




                        }
                        return Ok();


                    }
                    else
                    {
                        return BadRequest();
                    }



                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError); // error with the server(json), maybe something wrong with the structure of thejson
            }

        }




    }


}

//backoroud proccess  gia na kamnei update to status tou kathe game sto ticket 

