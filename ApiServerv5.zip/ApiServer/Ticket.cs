﻿namespace ApiServer
{
    public class Ticket
    {
        private int id;
        private DateTime date;
        private string status;
        private List<AvailableBet> bets;
        private float amount;
        private float income;

        public Ticket()
        {

        }
        public Ticket(Ticket newTicketh)
        {
            this.id = newTicketh.id;
            this.status = newTicketh.status;
            this.bets = new List<AvailableBet>(newTicketh.Bets);
            this.amount = newTicketh.amount;
            this.income = newTicketh.income;
        }
        public DateTime Date
        {
            get { return this.date; } 
            set {  this.date = value; }

        }
        public int Id {
            get { return id; }
            set { id = value; }
        }
        public  string Status
        {
            get
            {
                return status;
            }
            set { status = value; }

        }
        public List<AvailableBet> Bets
        {
            get { return  bets; }
            set { bets =new List<AvailableBet>(value); }
        }
        public float Amount
        {
            get
            { return amount; } 
            set 
            { amount = value; }
        }
        public float Income
        {
            get { return income; }
            set { income = value; }
        }
    }
}
