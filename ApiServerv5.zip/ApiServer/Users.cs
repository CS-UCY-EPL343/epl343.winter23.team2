﻿namespace ApiServer
{
    public class User
    {
        private string name;
        private string email;
        private string password;
        private int phone;
        private string surname;


        public string Name

        {
            get { return name; }

            set { name = value; }
        }
        public string Email

        {
            get { return email; }

            set { email = value; }
        }
        public string Password

        {
            get { return password; }

            set { password = value; }
        }
        public int Phone
        {
            get { return phone; }
            set { phone = value; }
        }
        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }


    }
}