﻿using Humanizer.Localisation.DateToOrdinalWords;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Xml.Linq;
using WebApplication1.Helpers;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        string baseURL = "http://localhost:5240/api/Home/";
        static int indexer = 0;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        /* When the application starts the program makes 2
         * requests to the api to get from its database:
         * 1. Get matches
         * 2. Get bets
         * It stores them in an static variable in order to 
         * be accesible and unchangeble throught the function
         * of the app
      */
        [HttpGet]  
        public async Task<IActionResult> Index()
        {
            IEnumerable<Match> mat = null;
            
                IList<Match> matches = new List<Match>();
                IList<Bet> bets = new List<Bet>();

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseURL);
                    HttpResponseMessage getData = await client.GetAsync("GetAllMatches");

                    if (getData.IsSuccessStatusCode)
                    {
                        string results = await getData.Content.ReadAsStringAsync();
                        matches = JsonConvert.DeserializeObject<List<Match>>(results);
                    }
                    else
                    {
                        Console.WriteLine("Error calling web Api");
                    }
                }

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseURL);
                    HttpResponseMessage getData = await client.GetAsync("GetAllBets");

                    if (getData.IsSuccessStatusCode)
                    {
                        string results = await getData.Content.ReadAsStringAsync();
                        bets     = JsonConvert.DeserializeObject<List<Bet>>(results);
                    }
                    else
                    {
                        Console.WriteLine("Error calling web Api");
                    }
                }
                List<Match> m = matches.ToList();
                List<Bet> b = bets.ToList();
                if (matches != null && bets != null)
                {
                    DataRetriver.Games.Bets = b;
                    DataRetriver.Games.Matches = m;
                }
                DataRetriver.Games.ClientTicket = new();
                DataRetriver.Games.ClientTicket.Bets = new();
            

            return View(mat);
        }
        
        [HttpGet]
        public IActionResult ShowResults()
        {
            
            return View();
        }

        /* This is the Admin Page where the administrator
         * can choose wether the bets are finished and are
         * won or lost
      */

        public async Task<IActionResult> AdministratorPage()
         {
            return View(DataRetriver.Games); 
         }

        /* Sends an bet id to the api and
         * to make its status won
      */
        public async Task<IActionResult> BetWon(int id)
        {
            
            foreach (Bet bet in DataRetriver.Games.Bets)
            {
                if(bet.Id == id)
                {
                    bet.Status = "won";
                    using (var client = new HttpClient())
                    {      
                        client.BaseAddress = new Uri(baseURL);

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, "FinishBet");

                        var stringContent = new StringContent(JsonConvert.SerializeObject(bet), UnicodeEncoding.UTF8, "application/json");

                        request.Content = stringContent;

                        HttpResponseMessage getData = await client.SendAsync(request);

                        if (getData.IsSuccessStatusCode)
                        {
                            return RedirectToAction("AdministratorPage");

                        }
                        else
                        {
                            Console.WriteLine("Error calling web Api");
                        }
                    }
                    break;
                }
            }
            return RedirectToAction("Index");
        }

        /* Sends an bet id to the api and
         * to make its status lost
      */
        public async  Task<IActionResult> BetLost(int id)
        {

            foreach (Bet bet in DataRetriver.Games.Bets)
            {
                if (bet.Id == id)
                {
                    bet.Status = "lost";
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(baseURL);

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, "FinishBet");

                        var stringContent = new StringContent(JsonConvert.SerializeObject(bet), UnicodeEncoding.UTF8, "application/json");

                        request.Content = stringContent;

                        HttpResponseMessage getData = await client.SendAsync(request);

                        if (getData.IsSuccessStatusCode)
                        {
                            return RedirectToAction("AdministratorPage");

                        }
                        else
                        {
                            Console.WriteLine("Error calling web Api");
                        }
                    }
                    break;
                }
            }
            return RedirectToAction("Index");
        }
        public IActionResult Privacy()
        {
           return View();
        }

       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}