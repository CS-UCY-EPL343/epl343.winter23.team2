﻿using Microsoft.Extensions.Options;
using System.Net.Http;
using WebApplication1.Models;

namespace HttpClientStatus;
public class MyService////////////
{
    
        static async Task Main(string[] args)
        {
            using var client = new HttpClient();

            var result = await client.GetAsync("http://webcode.me");
            Console.WriteLine(result.StatusCode);
        }
    }

    
    
    /*
    private readonly HttpClient _httpClient;
    private readonly MyApiConfiguration _apiSettings;

    public MyService(HttpClient httpClient, IOptions<MyApiConfiguration> apiSettings)
    {
        _httpClient = httpClient;
        _apiSettings = apiSettings.Value;

        // Set the API base URL for the HttpClient
        _httpClient.BaseAddress = new Uri(_apiSettings.ApiBaseUrl);
    }

    public async Task<string> GetApiResponseAsync()
    {
        // Append any required headers, authentication tokens, etc., to the request if needed
        _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiSettings.ApiKey}");

        // Send the GET request to the API and handle the response
        HttpResponseMessage response = await _httpClient.GetAsync("api/endpoint");
        response.EnsureSuccessStatusCode(); // Ensure the response is successful

        // Read the response content
        string responseBody = await response.Content.ReadAsStringAsync();

        return responseBody;
    }*/


