﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using WebApplication1.Helpers;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ViewTicketsController : Controller
    {
        string baseURL = "http://localhost:5240/api/Home/";

      
        public async Task<IActionResult> Index()
        {
            ViewTicket viewTicket = new ViewTicket(); 
            IList<Ticket> tickets = new List<Ticket>();
            IList<Match> matches = new List<Match>(); 
            using (var client = new HttpClient())  //client request to api
            {

                client.BaseAddress = new Uri(baseURL);
                HttpResponseMessage getData = await client.GetAsync("GetAllMatches");

                if (getData.IsSuccessStatusCode)
                {
                    string results = await getData.Content.ReadAsStringAsync();
                    matches = JsonConvert.DeserializeObject<List<Match>>(results);
                }
                else
                {
                    Console.WriteLine("Error calling web Api");
                }
            }
            using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseURL);
                    HttpResponseMessage getData = await client.GetAsync("GetAllTickets");

                    if (getData.IsSuccessStatusCode)
                    {
                        string results = await getData.Content.ReadAsStringAsync();
                        tickets = JsonConvert.DeserializeObject<List<Ticket>>(results);
                    }
                    else
                    {
                        Console.WriteLine("Error calling web Api");
                    }
                }
            viewTicket.tickets = (List<Ticket>)tickets;
            viewTicket.matches = (List<Match>)matches;
                return View(viewTicket);
         }

          
        
    }
}
