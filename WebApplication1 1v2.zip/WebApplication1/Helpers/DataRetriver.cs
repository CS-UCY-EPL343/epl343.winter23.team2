﻿using NuGet.Protocol;
using System.Security.Cryptography.X509Certificates;
using WebApplication1.Models;

namespace WebApplication1.Helpers
{

    /// <summary>
    /// Creating a static list of games that are deleted 
    /// when the app is turn off
    /// </summary>

    public static class DataRetriver
    {
        
        public static GamesToBet Games = new GamesToBet();
      
        public static void AddBet(Bet bet)
        {
            Games.ClientTicket.Bets.Add(bet);
        }

        private static void DeleteBet(Bet bet)
        {
            Games.ClientTicket.Bets.Remove(bet);
        }

        public static int EditTicket(int betid)
        {
            foreach (Bet bet in Games.ClientTicket.Bets)
            {
                if (bet.Id == betid)
                {
                    DeleteBet(bet);
                    return 1;
                }

            }
            foreach (Bet bet in Games.Bets)
            {
                if (bet.Id == betid)
                {
                    foreach (Bet bet1 in Games.ClientTicket.Bets)
                    {
                        if (bet1.MatchId==bet.MatchId)
                        {
                            return 0;//exeception you cant play more than one bet in a single match
                        }
                    }
                    if (bet.Id == betid)
                    {
                        AddBet(bet);
                        
                    }
                }
            }
          return 1;

         }
        public static void FindIncome(GamesToBet games)
        {
            if (games != null && games.ClientTicket != null)
            {
                DataRetriver.Games.ClientTicket.Amount = games.ClientTicket.Amount;
                DataRetriver.Games.ClientTicket.Income = 0;
                foreach (Bet bet in DataRetriver.Games.ClientTicket.Bets)
                {
                    DataRetriver.Games.ClientTicket.Income+= games.ClientTicket.Amount * bet.Odd;
                }
            }
            return;
            
        }

    }
}
