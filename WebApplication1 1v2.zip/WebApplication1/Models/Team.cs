﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.Xml;
namespace WebApplication1.Models
{
    public class Team
    {
        public string Name { get; set; } = string.Empty;
    }
}
