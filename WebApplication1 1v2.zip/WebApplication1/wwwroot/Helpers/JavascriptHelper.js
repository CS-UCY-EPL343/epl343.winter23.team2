
function changeColor() {
    var element = document.getElementsByClassName("btn btn-outline-primary");
    element.className = "btn btn-primary";
}