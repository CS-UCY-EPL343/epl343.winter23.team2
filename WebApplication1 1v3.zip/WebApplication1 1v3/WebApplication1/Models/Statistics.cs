﻿namespace WebApplication1.Models
{
    public class Statistics
    {
        public List<Team> Teams { get; set; }
    }
}
