﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.Xml;
namespace WebApplication1.Models
{
    public class User
    {
        public string Name { get; set; } = string.Empty;

        public string Surname { get; set; } = string.Empty;

        public string Username { get; set; } = string.Empty;

        public int Id { get; set; }

        public string Password { get; set; } = string.Empty;

        public int Phone { get; set; }

        public List<Ticket> Tickets { get; set; }

        public Statistics UserStatistics { get; set; }

    }
}
