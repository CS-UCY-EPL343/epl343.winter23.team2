using System.Text.RegularExpressions;
using WebApplication1.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddControllers();

//builder.Services.Configure<MyApiConfiguration>(builder.Configuration.GetSection("MyApiConfiguration"));///////

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

//Diavazo apo edo ta configurations apo to appsettings
//how to read from appsetting in .net6

app.UseRouting();





//app.UseEndpoints(endpoints =>
//{
//   endpoints.MapControllers();
//});

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
