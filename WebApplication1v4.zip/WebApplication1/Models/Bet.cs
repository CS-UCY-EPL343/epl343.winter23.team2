﻿namespace WebApplication1.Models
{
    public class Bet
    {
        public  int MatchId { get; set; }

        public string Name { get; set; }
      
        public int Id { get; set; }  

        public float Odd { get; set; }

        public string Status { get; set; } = "open";

    }
}
