﻿namespace WebApplication1.Models
{
    public class GamesToBet
    {

        public List<Bet> Bets { get; set; } = new();

        public List<Match> Matches { get; set; } = new();

        public Ticket ClientTicket { get; set; } = new();

    }
}