﻿using Microsoft.AspNetCore.Http;

namespace WebApplication1.Models
{
    public class ReturnBase
    {
        public int Id
        { get; set; }
        public string Message
        {
            get; set;
        } = string.Empty;
        public int StatusCode
        {
            get;set;
        }
    }
}
