﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using NuGet.Protocol;
using System.Data;
using System.Diagnostics;
using System.Net.Mail;
using System.Text;
using System.Xml.Linq;
using WebApplication1.Helpers;
using WebApplication1.Models;
using System.Drawing;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Microsoft.CodeAnalysis;
using System.Reflection;
using System.Net.Http;

namespace WebApplication1.Controllers
{
    public class BetController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        string baseURL = "http://localhost:5240/api/Home/";
        static int indexer = 0;

        private MediaTypeWithQualityHeaderValue MediaTypeWithQualityHeaderValue(string v)
        {
            throw new NotImplementedException();
        }

        /* Stores a bet in a ticket or removes it
         * if it's already been played. The id of
         * the bet is chosen on button click by the 
         * client
      */
        public IActionResult TicketAction(int id)
        {
                int errorHandler = DataRetriver.EditTicket(id);// Static function
                if (errorHandler == 0)
                {
                    TempData["AlertMessage"] = "You are not allowed to play more than one bet for a single game";
                }
            
           
            return RedirectToAction("Index");
        }

      /* Client request to send a ticket to an 
       * api in order to store it in a json  
       */

        public async Task<IActionResult> PostTicketAsync()
        {
            ReturnBase response = new ReturnBase();
            using (var client = new HttpClient()) 
            {

                client.BaseAddress = new Uri(baseURL);

                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "PostTicket");

                var stringContent = new StringContent(JsonConvert.SerializeObject(DataRetriver.Games.ClientTicket), UnicodeEncoding.UTF8, "application/json");

                request.Content = stringContent;

                HttpResponseMessage getData = await client.SendAsync(request);
               if (getData.IsSuccessStatusCode == true)
            {
                    string results = await getData.Content.ReadAsStringAsync();
                    response = JsonConvert.DeserializeObject<ReturnBase>(results);
                        return RedirectToAction("Index");
                   
            } 

            }
            

            return RedirectToAction("Index");

        }
        /* Sending Amount to be played with the help of 
         * @GamesToBet object and calculating the income 
         * to show to the client
       */
        [HttpGet]
        public async Task<IActionResult> Index(GamesToBet games)
        {

           DataRetriver.FindIncome(games);
        
            return View(DataRetriver.Games);
        } 
      
        public IActionResult Create()
        {
            return View();
        }

    }
}
