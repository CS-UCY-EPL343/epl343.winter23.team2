﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;
using WebApplication1.Helpers;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class StatisticsController : Controller
    {
        string baseURL = "http://localhost:5240/api/Home/";

        public async Task<IActionResult> Index()
        {
            UserStatistic uStatistics = new UserStatistic();
            ViewTicket viewTicket = new ViewTicket();
            IList<Ticket> tickets = new List<Ticket>();
            IList<Match> matches = new List<Match>();
            using (var client = new HttpClient())  //client request to api
            {

                client.BaseAddress = new Uri(baseURL);
                HttpResponseMessage getData = await client.GetAsync("GetAllMatches");

                if (getData.IsSuccessStatusCode)
                {
                    string results = await getData.Content.ReadAsStringAsync();
                    matches = JsonConvert.DeserializeObject<List<Match>>(results);
                }
                else
                {
                    Console.WriteLine("Error calling web Api");
                }
            }
            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(baseURL);
                HttpResponseMessage getData = await client.GetAsync("GetAllTickets");

                if (getData.IsSuccessStatusCode)
                {
                    string results = await getData.Content.ReadAsStringAsync();
                    tickets = JsonConvert.DeserializeObject<List<Ticket>>(results);
                }
                else
                {
                    Console.WriteLine("Error calling web Api");
                }
            }
            viewTicket.tickets = (List<Ticket>)tickets;
            viewTicket.matches = (List<Match>)matches;
            foreach (Ticket ticket in viewTicket.tickets)
            {
                foreach (Bet bet in ticket.Bets)
                {
                    if (bet.Status.Equals("lost"))
                    {
                        ticket.Status = "lost";
                        break;
                    }
                    else
                    {
                        ticket.Status = "won";
                    }
                }

            }
            List<Team> teams = new List<Team>();
            List<int> counts = new List<int>();
            foreach (Match match in matches)
            {
                if (!teams.Contains(match.Team1))
                {
                    teams.Add(match.Team1);
                    counts.Add(0);
                }
                if (!teams.Contains(match.Team2))
                {
                    teams.Add(match.Team2);
                    counts.Add(0);
                }
            }
            String teamName = "";
            String teamName1 = "";
            String teamName2 = "";
            foreach (Ticket ticket in viewTicket.tickets)
            {
                if (ticket.Status.Equals("won"))
                {
                    uStatistics.MoneyWon = uStatistics.MoneyWon + ticket.Income;
                }
                else
                {
                    uStatistics.MoneyLost = uStatistics.MoneyLost - ticket.Amount;
                }
                uStatistics.MoneyFlow = uStatistics.MoneyLost + uStatistics.MoneyWon;
                foreach (Bet bet in ticket.Bets)
                {

                    if (bet.Name.Equals("Home_win"))
                    {
                        foreach (Match match in matches)//Finds team won
                        {
                            if (match.Id == bet.MatchId)
                            {
                                teamName = match.Team1.Name;
                                break;
                            }
                        }
                        for (int i = 0; i < teams.Count; i++)
                        {
                            if (teams[i].Name.Equals(teamName))
                            {
                                counts[i]++;
                            }
                        }
                    }
                    else if (bet.Name.Equals("Away_win"))
                    {
                        foreach (Match match in matches)//Finds team won
                        {
                            if (match.Id == bet.MatchId)
                            {
                                teamName = match.Team2.Name;
                                break;
                            }
                        }
                        for (int i = 0; i < teams.Count; i++)
                        {
                            if (teams[i].Name.Equals(teamName))
                            {
                                counts[i]++;
                            }
                        }
                    }
                    else
                    {
                        foreach (Match match in matches)//Finds team won
                        {
                            if (match.Id == bet.MatchId)
                            {
                                teamName1 = match.Team1.Name;
                                teamName2 = match.Team2.Name;
                                break;
                            }
                        }
                        for (int i = 0; i < teams.Count; i++)
                        {
                            if (teams[i].Name.Equals(teamName1))
                            {
                                counts[i]++;
                            }
                            if (teams[i].Name.Equals(teamName2))
                            {
                                counts[i]++;
                            }
                        }
                    }
                }
            }
            int max = 0, k = 0, j = 0, min = int.MaxValue;
            for (int i = 0; i < counts.Count; i++)//Parousiazi mono mia
            {
                if (counts[i] > max)
                {
                    max = counts[i];
                    k = i;
                }
                if (counts[i] < min)
                {
                    min = counts[i];
                    j = i;
                }
            }
            uStatistics.MostProfitableTeam = teams[k].Name;
            uStatistics.LeastProfitableTeam = teams[j].Name;
            uStatistics.months = new List<int>();
            uStatistics.monthsTicketLost = new List<int>();
            uStatistics.monthsTicketWon = new List<int>();
            for (int i = 0; i < 12; i++)
            {
                uStatistics.months.Add(0);
                uStatistics.monthsTicketLost.Add(0);
                uStatistics.monthsTicketWon.Add(0);
            }
            foreach (Ticket ticket in viewTicket.tickets)
            {
                if (ticket.Status.Equals("won"))
                {
                    uStatistics.monthsTicketWon[ticket.Date.Month - 1]++;
                }
                else
                {
                    uStatistics.monthsTicketLost[ticket.Date.Month - 1]++;
                }
            }
            uStatistics.WonRatePerMonth = new List<float>();
            for(int i = 0;i < 12; i++)
            {

                uStatistics.WonRatePerMonth.Add(((float)uStatistics.monthsTicketWon[i] / (float)(uStatistics.monthsTicketWon[i] + uStatistics.monthsTicketLost[i]))*100);
            }
            uStatistics.monthNames = new List<string>();
            uStatistics.monthNames.Add("January");
            uStatistics.monthNames.Add("February");
            uStatistics.monthNames.Add("March");
            uStatistics.monthNames.Add("April");
            uStatistics.monthNames.Add("May");
            uStatistics.monthNames.Add("June");
            uStatistics.monthNames.Add("July");
            uStatistics.monthNames.Add("August");
            uStatistics.monthNames.Add("September");
            uStatistics.monthNames.Add("October");
            uStatistics.monthNames.Add("November");
            uStatistics.monthNames.Add("December");
           
            return View(uStatistics);
        }
    }
}
