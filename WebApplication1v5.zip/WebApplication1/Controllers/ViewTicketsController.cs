﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using Newtonsoft.Json;
using System;
using WebApplication1.Helpers;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ViewTicketsController : Controller
    {
        string baseURL = "http://localhost:5240/api/Home/";

      
        public async Task<IActionResult> Index()
        {
            ViewTicket viewTicket = new ViewTicket(); 
            IList<Ticket> tickets = new List<Ticket>();
            IList<Match> matches = new List<Match>(); 
            using (var client = new HttpClient())  //client request to api
            {

                client.BaseAddress = new Uri(baseURL);
                HttpResponseMessage getData = await client.GetAsync("GetAllMatches");

                if (getData.IsSuccessStatusCode)
                {
                    string results = await getData.Content.ReadAsStringAsync();
                    matches = JsonConvert.DeserializeObject<List<Match>>(results);
                }
                else
                {
                    Console.WriteLine("Error calling web Api");
                }
            }
            using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseURL);
                    HttpResponseMessage getData = await client.GetAsync("GetAllTickets");

                    if (getData.IsSuccessStatusCode)
                    {
                        string results = await getData.Content.ReadAsStringAsync();
                        tickets = JsonConvert.DeserializeObject<List<Ticket>>(results);
                    }
                    else
                    {
                        Console.WriteLine("Error calling web Api");
                    }
                }
            viewTicket.tickets = (List<Ticket>)tickets;
            viewTicket.matches = (List<Match>)matches;
            foreach(Ticket ticket in viewTicket.tickets)
            {
                foreach(Bet bet in ticket.Bets)
                {
                    if (bet.Status.Equals("lost"))
                    {
                        ticket.Status = "lost";
                        break;
                    }
                    else
                    {
                        ticket.Status = "won";
                    }
                }

            }
                return View(viewTicket);
         }

        
        public async Task<IActionResult> deleteTicket(int ticketid)
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseURL);

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("Deleteticket?ticketid=" + ticketid);
                deleteTask.Wait();

                var result = deleteTask.Result;
           //     client.BaseAddress = new Uri(baseURL);

                // Specify the match ID you want to delete
                

             //   HttpResponseMessage deleteResponse = await client.DeleteAsync($"Deleteticket/{ticketid}");

                if (result.IsSuccessStatusCode)
                {
                    Console.WriteLine("Match deleted successfully");
                }
                else
                {
                    Console.WriteLine("Error deleting match");
                }
            }
            return RedirectToAction("Index");
        }
        
    }
}
