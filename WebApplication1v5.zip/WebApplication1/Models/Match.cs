﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.Xml;

namespace WebApplication1.Models
{

    public enum Mtype
    {
        Football = 1,
        Basketball = 2,
        Tennis = 3,
    }//enum

    public class Match
    {
        public string Name { get; set; } = string.Empty;

        public Team Team1 { get; set; }

        public Team Team2 { get; set; }

        public int Id { get; set; }

        public Mtype MatchType { get; set; }

        public DateTime Date { get; set; }

    }
}
