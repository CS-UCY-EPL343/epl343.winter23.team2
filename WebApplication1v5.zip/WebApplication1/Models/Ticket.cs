﻿namespace WebApplication1.Models
{
    public class Ticket
    {
        public List<Bet> Bets{ get; set; }

        public DateTime Date = System.DateTime.Now;

        public string Status { get; set; } = string.Empty;
        
        public int Id { get; set; }

        public float Amount { get; set; }

        public float Income
        {
            get;
            set;
        }


    }
}
