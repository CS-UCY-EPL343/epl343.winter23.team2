﻿namespace WebApplication1.Models
{
    public class UserStatistic
    {
        public String MostProfitableTeam { get; set; } = string.Empty;

        public String LeastProfitableTeam { get; set; } = string.Empty;

        public float MoneyWon { get; set; } = 0;

        public float MoneyLost { get; set; } = 0;

        public float MoneyFlow { get; set; } = 0;

        public List<String> monthNames { get; set; }

        public List<int> months { get; set; }

        public List<int> monthsTicketWon {  get; set; }

        public List<int> monthsTicketLost { get; set; }

        public List<float> WonRatePerMonth { get; set; }





    }
}
