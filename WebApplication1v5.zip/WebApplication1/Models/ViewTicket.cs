﻿namespace WebApplication1.Models
{
    /*
     * Gia na emfaniso ta tickets sto ViewTicket
     */
    public class ViewTicket
    {
        
            public List<Ticket> tickets = new List<Ticket>();

            public List<Match> matches = new List<Match>();
        
    }
}
